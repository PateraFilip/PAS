load("C:/Users/helik/Dropbox/Vyuka/Predmety/PAS_IS/PAS_API_testy_AaL/Studenti_2024-01-16/Math.RData")
attach(Math)

library(DescTools)

