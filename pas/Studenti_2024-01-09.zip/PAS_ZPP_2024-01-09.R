load("E:\\Aja\\Prirodoveda\\Statistika\\dataZS\\prij.RData")
attach(prij)
library(DescTools)